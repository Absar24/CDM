﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MobileInfoWebApp.BLL;
using MobileInfoWebApp.DAL.Model;

namespace MobileInfoWebApp.UI
{
    public partial class SearchMobile : System.Web.UI.Page
    {
        MobileManeger mobileManeger=new MobileManeger();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                mobileGridView.DataSource = mobileManeger.GetAllMobile();
                mobileGridView.DataBind();
            }
           
            
        }

        protected void prSearchButton_Click(object sender, EventArgs e)
        {

            MobileInfo mobile1 = new MobileInfo();
            mobile1.Pricebetween = Convert.ToInt32(PriceBetweenTextBox.Text);
            mobile1.Andprice = Convert.ToInt32(andTextBox.Text);
            mobileGridView.DataSource = mobileManeger.Searchmobiles(mobile1);
            mobileGridView.DataBind();
        }
    }
}