﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MobileInfoWebApp.BLL;
using MobileInfoWebApp.DAL.Model;

namespace MobileInfoWebApp.UI
{
    public partial class SaveMobileInfo : System.Web.UI.Page
    {
      public MobileManeger MobileManeger=new MobileManeger();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void saveButton_Click(object sender, EventArgs e)
        {
            MobileInfo mobile=new MobileInfo();
            mobile.ModelName = ModelNameTextBox.Text;
            mobile.Imei = IMEITextBox.Text;
            mobile.Price = Convert.ToInt32(PriceTextbox.Text);
            outputlavel.Text= MobileManeger.Save(mobile);
        }
    }
}