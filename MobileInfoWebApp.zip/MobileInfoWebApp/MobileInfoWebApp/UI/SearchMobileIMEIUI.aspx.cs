﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MobileInfoWebApp.BLL;
using MobileInfoWebApp.DAL.Model;

namespace MobileInfoWebApp.UI
{
    public partial class SearchMobileIMEIUI : System.Web.UI.Page
    {
        MobileManeger mobileManeger=new MobileManeger();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void imeiSearchButton_Click(object sender, EventArgs e)
        {
            
            string imei = IMEITextBox.Text;
            MobileInfo mobile=mobileManeger.GetMobilesImei(imei);
            modelNameLabel.Text = mobile.ModelName;
            imeiLabel.Text = mobile.Imei;
            PriceLavel.Text = mobile.Price.ToString();
        }
    }
}