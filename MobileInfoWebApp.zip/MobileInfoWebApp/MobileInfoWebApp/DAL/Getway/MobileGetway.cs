﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using MobileInfoWebApp.DAL.Model;

namespace MobileInfoWebApp.DAL.Getway
{
    public class MobileGetway
    {
        private string connectionString = WebConfigurationManager.ConnectionStrings["MobileDB"].ConnectionString;

        private SqlConnection Connection { get; set; }
        public SqlCommand Command { get; set; }
        public SqlDataReader Reader { get; set; }

        public MobileGetway()
        {
            Connection=new SqlConnection(connectionString);
         }
        public int Save(MobileInfo mobile)
        {
            Connection = new SqlConnection(connectionString);
           string query = "INSERT INTO MobileTB VALUES('" + mobile.ModelName + "','" + mobile.Imei + "','" + mobile.Price + "')";
            Command = new SqlCommand(query, Connection);
            Connection.Open();
            int rowAffect = Command.ExecuteNonQuery();
            Connection.Close();

            return rowAffect;
        }
        public bool IsReNoExists(string Imei)
        {
            string query = "SELECT * FROM MobileTB WHERE IMEI='" +Imei+ "'";
            Command = new SqlCommand(query, Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();

            bool isExists = Reader.HasRows;

            Connection.Close();

            return isExists;
        }

        public List<MobileInfo> GetAllMobiles()
        {
            string query = "SELECT * FROM MobileTB";
            Command = new SqlCommand(query, Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            List<MobileInfo> mobiles = new List<MobileInfo>();
            while (Reader.Read())
            {
               MobileInfo mobile=new MobileInfo();
                mobile.Id = Convert.ToInt32(Reader["Id"]);
                mobile.ModelName = Reader["ModelName"].ToString();
                mobile.Imei = Convert.ToString(Reader["IMEI"]); 
                mobile.Price = Convert.ToInt32(Reader["Price"]);
                mobiles.Add(mobile);
            }
            Connection.Close();
            return mobiles;
        }

        public List<MobileInfo> Searchmobiles(int pbetweemn,int andprice )
        {
           
            string query="SELECT * FROM MobileTB WHERE Price BETWEEN'"+pbetweemn+"' AND '" +andprice+"'";
            Command = new SqlCommand(query, Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            List<MobileInfo> mobiles = new List<MobileInfo>();
            while (Reader.Read())
            {
                MobileInfo mobile1 = new MobileInfo();
                mobile1.Id = Convert.ToInt32(Reader["Id"]);
                mobile1.ModelName = Reader["ModelName"].ToString();
                mobile1.Imei = Convert.ToString(Reader["IMEI"]);
                mobile1.Price = Convert.ToInt32(Reader["Price"]);
                mobiles.Add(mobile1);
            }
            Connection.Close();
            return mobiles;
        }

        public MobileInfo GetMobilesImei(string imei)
        {
            string query = "SELECT * FROM MobileTB WHERE IMEI='"+imei+"'";
            Command = new SqlCommand(query, Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            Reader.Read();
            MobileInfo mobile = new MobileInfo();
            mobile.ModelName = Reader["ModelName"].ToString();
            mobile.Imei = Convert.ToString(Reader["IMEI"]);
            mobile.Price = Convert.ToInt32(Reader["Price"]);
          
            
            Connection.Close();
            return mobile;
        }











       
    }
}