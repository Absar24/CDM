﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MobileInfoWebApp.DAL.Model
{
    public class MobileInfo
    {
        public int Id { get; set; }
        public string ModelName { get; set; }
        public string Imei { get; set; }
        public int Price { get; set; }
        public int Pricebetween { get; set; }
        public int Andprice { get; set; }   

    }
}