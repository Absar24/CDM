﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MobileInfoWebApp.DAL.Getway;
using MobileInfoWebApp.DAL.Model;

namespace MobileInfoWebApp.BLL
{
    public class MobileManeger
    {
       public MobileGetway MobileGetway=new MobileGetway();
       public string Save(MobileInfo mobile)
       {
           if (MobileGetway.IsReNoExists(mobile.Imei))
           {
               return "IMEI Already Exists";
           }

           else
           {
               if (mobile.Imei.Length < 15)
               {
                   return "IMEI must have 15 number";
               }
               int rowAffect = MobileGetway.Save(mobile);

               if (rowAffect > 0)
               {
                   return "Save Successful";
               }
               else
               {
                   return "Save Failed";
               }
           } 
       }

        public List<MobileInfo> GetAllMobile()
        {
            List<MobileInfo> mobiles = MobileGetway.GetAllMobiles();
            return mobiles;
        }

        public List<MobileInfo> Searchmobiles(MobileInfo mobile)
        {
            List<MobileInfo> mobiles = MobileGetway.Searchmobiles(mobile.Pricebetween,mobile.Andprice);
            return mobiles;
        }

        public MobileInfo GetMobilesImei(string imei)
        {
          return MobileGetway.GetMobilesImei(imei);
        }
       
    }
}
